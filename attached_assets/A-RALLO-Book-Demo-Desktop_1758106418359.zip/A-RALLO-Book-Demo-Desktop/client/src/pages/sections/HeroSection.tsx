import { ChevronRightIcon } from "lucide-react";
import React from "react";
import { Button } from "@/components/ui/button";

const features = [
  "Chat agents that never sleep",
  "Voice interactions at scale",
  "Video conversations on demand",
];

export const HeroSection = (): JSX.Element => {
  return (
    <section className="flex flex-col items-center gap-20 px-16 py-28 relative self-stretch w-full flex-[0_0_auto] bg-white">
      <div className="flex flex-col max-w-screen-xl items-start gap-20 relative w-full flex-[0_0_auto]">
        <div className="items-center flex gap-20 relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex-col items-start gap-8 flex-1 grow flex relative">
            <div className="flex-col items-start gap-8 self-stretch w-full flex-[0_0_auto] flex relative">
              <div className="flex flex-col items-start gap-4 relative self-stretch w-full flex-[0_0_auto]">
                <div className="inline-flex items-center relative flex-[0_0_auto]">
                  <div className="relative w-fit mt-[-1.00px] font-heading-tagline font-[number:var(--heading-tagline-font-weight)] text-black text-[length:var(--heading-tagline-font-size)] tracking-[var(--heading-tagline-letter-spacing)] leading-[var(--heading-tagline-line-height)] whitespace-nowrap [font-style:var(--heading-tagline-font-style)]">
                    Intelligent
                  </div>
                </div>

                <div className="flex flex-col items-start gap-6 relative self-stretch w-full flex-[0_0_auto]">
                  <h1 className="relative self-stretch mt-[-1.00px] font-heading-h2 font-[number:var(--heading-h2-font-weight)] text-black text-[length:var(--heading-h2-font-size)] tracking-[var(--heading-h2-letter-spacing)] leading-[var(--heading-h2-line-height)] [font-style:var(--heading-h2-font-style)]">
                    Experience the future of ai-powered engagement
                  </h1>

                  <p className="relative self-stretch font-text-medium-normal font-[number:var(--text-medium-normal-font-weight)] text-black text-[length:var(--text-medium-normal-font-size)] tracking-[var(--text-medium-normal-letter-spacing)] leading-[var(--text-medium-normal-line-height)] [font-style:var(--text-medium-normal-font-style)]">
                    See how Rallo&#39;s AI agents seamlessly handle customer
                    interactions across multiple channels. Transform your
                    business communication with intelligent, always-on
                    representation.
                  </p>
                </div>
              </div>

              <ul className="flex flex-col items-start gap-4 relative self-stretch w-full flex-[0_0_auto]">
                {features.map((feature, index) => (
                  <li
                    key={index}
                    className="flex items-center gap-4 relative self-stretch w-full flex-[0_0_auto]"
                  >
                    <div className="relative flex-1 mt-[-1.00px] font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-black text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] [font-style:var(--text-regular-normal-font-style)]">
                      {feature}
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="inline-flex items-center gap-6 relative flex-[0_0_auto]">
              <Button
                variant="outline"
                className="h-auto px-6 py-3 border-black text-black hover:bg-black hover:text-white font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] [font-style:var(--text-regular-normal-font-style)]"
              >
                Explore
              </Button>

              <Button
                variant="ghost"
                className="h-auto p-0 text-black hover:bg-transparent font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] [font-style:var(--text-regular-normal-font-style)]"
              >
                Watch
                <ChevronRightIcon className="ml-2 w-6 h-6" />
              </Button>
            </div>
          </div>

          <img
            className="relative flex-1 grow h-[640px] object-cover"
            alt="Placeholder image"
            src="/figmaAssets/placeholder-image.png"
          />
        </div>
      </div>
    </section>
  );
};
