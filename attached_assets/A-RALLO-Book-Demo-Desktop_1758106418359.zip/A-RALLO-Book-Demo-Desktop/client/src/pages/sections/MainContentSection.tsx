import { ChevronRightIcon } from "lucide-react";
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const steps = [
  {
    number: "STEP 1",
    icon: "/figmaAssets/relume.svg",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.",
  },
  {
    number: "STEP 2",
    icon: "/figmaAssets/relume.svg",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.",
  },
  {
    number: "STEP 3",
    icon: "/figmaAssets/relume.svg",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.",
  },
  {
    number: "STEP 4",
    icon: "/figmaAssets/relume.svg",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat.",
  },
];

export const MainContentSection = (): JSX.Element => {
  return (
    <section className="flex flex-col items-center gap-20 px-16 py-28 w-full bg-white">
      <div className="flex flex-col max-w-screen-xl items-start gap-20 w-full">
        <div className="items-start flex gap-20 w-full">
          <div className="flex-col items-start gap-8 flex-1 grow flex">
            <div className="flex flex-col items-start gap-4 w-full">
              <div className="inline-flex items-center">
                <div className="w-fit mt-[-1.00px] font-heading-tagline font-[number:var(--heading-tagline-font-weight)] text-black text-[length:var(--heading-tagline-font-size)] tracking-[var(--heading-tagline-letter-spacing)] leading-[var(--heading-tagline-line-height)] whitespace-nowrap [font-style:var(--heading-tagline-font-style)]">
                  Personalized
                </div>
              </div>

              <div className="flex flex-col items-start gap-6 w-full">
                <h2 className="mt-[-1.00px] font-heading-h2 font-[number:var(--heading-h2-font-weight)] text-black text-[length:var(--heading-h2-font-size)] tracking-[var(--heading-h2-letter-spacing)] leading-[var(--heading-h2-line-height)] [font-style:var(--heading-h2-font-style)]">
                  Your custom rallo experience awaits
                </h2>

                <p className="font-text-medium-normal font-[number:var(--text-medium-normal-font-weight)] text-black text-[length:var(--text-medium-normal-font-size)] tracking-[var(--text-medium-normal-letter-spacing)] leading-[var(--text-medium-normal-line-height)] [font-style:var(--text-medium-normal-font-style)]">
                  We'll walk you through exactly how Rallo can be tailored to
                  your unique business needs and communication goals.
                </p>
              </div>
            </div>

            <div className="inline-flex items-center gap-6">
              <Button
                variant="outline"
                className="h-auto px-6 py-3 mt-[-1.00px] mb-[-1.00px] ml-[-1.00px] border border-solid border-black bg-white hover:bg-gray-50"
              >
                <span className="font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-black text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] [font-style:var(--text-regular-normal-font-style)]">
                  Schedule
                </span>
              </Button>

              <Button
                variant="ghost"
                className="h-auto p-0 hover:bg-transparent"
              >
                <span className="font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-black text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] [font-style:var(--text-regular-normal-font-style)]">
                  Learn More
                </span>
                <ChevronRightIcon className="w-6 h-6 ml-2" />
              </Button>
            </div>
          </div>

          <div className="flex-col items-start gap-8 flex-1 grow flex">
            {steps.map((step, index) => (
              <Card
                key={index}
                className="w-full bg-white border border-solid border-black"
              >
                <CardContent className="flex-col items-start gap-4 p-8">
                  <img className="w-12 h-12" alt="Relume" src={step.icon} />

                  <h3 className="font-heading-h5 font-[number:var(--heading-h5-font-weight)] text-black text-[length:var(--heading-h5-font-size)] tracking-[var(--heading-h5-letter-spacing)] leading-[var(--heading-h5-line-height)] [font-style:var(--heading-h5-font-style)]">
                    {step.number}
                  </h3>

                  <p className="font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-black text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] [font-style:var(--text-regular-normal-font-style)]">
                    {step.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
