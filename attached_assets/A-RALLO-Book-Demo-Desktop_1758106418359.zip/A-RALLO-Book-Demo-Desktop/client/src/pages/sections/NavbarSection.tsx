import React from "react";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "@/components/ui/navigation-menu";

export const NavbarSection = (): JSX.Element => {
  const navigationItems = [
    { label: "Products" },
    { label: "Pricing" },
    { label: "Solutions" },
  ];

  return (
    <nav className="flex flex-col h-[72px] items-center justify-center px-16 py-0 relative self-stretch w-full bg-white">
      <div className="flex items-center justify-between relative self-stretch w-full flex-[0_0_auto]">
        <div className="w-20 h-10 items-center justify-center flex relative">
          <div className="relative w-[84px] h-9 ml-[-2.00px] mr-[-2.00px]">
            <img
              className="absolute w-[70px] h-9 top-0 left-[7px]"
              alt="Logo wide"
              src="/figmaAssets/logo-wide-1.svg"
            />
          </div>
        </div>

        <div className="inline-flex items-center justify-center gap-8 relative flex-[0_0_auto]">
          <NavigationMenu>
            <NavigationMenuList className="inline-flex items-center justify-end gap-8 relative flex-[0_0_auto]">
              {navigationItems.map((item, index) => (
                <NavigationMenuItem
                  key={index}
                  className="inline-flex items-center justify-center gap-1 relative flex-[0_0_auto]"
                >
                  <NavigationMenuLink className="relative w-fit mt-[-1.00px] font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-black text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] whitespace-nowrap [font-style:var(--text-regular-normal-font-style)] cursor-pointer hover:opacity-70">
                    {item.label}
                  </NavigationMenuLink>
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>

          <div className="inline-flex items-center justify-center gap-4 relative flex-[0_0_auto]">
            <Button className="inline-flex items-center justify-center gap-2 px-5 py-2 relative flex-[0_0_auto] mt-[-2.00px] mb-[-2.00px] ml-[-2.00px] mr-[-2.00px] bg-black border border-solid h-auto hover:bg-gray-800">
              <span className="relative w-fit mt-[-1.00px] ml-[-1.00px] font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-white text-[length:var(--text-regular-normal-font-size)] tracking-[var(--text-regular-normal-letter-spacing)] leading-[var(--text-regular-normal-line-height)] whitespace-nowrap [font-style:var(--text-regular-normal-font-style)]">
                Demo
              </span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};
