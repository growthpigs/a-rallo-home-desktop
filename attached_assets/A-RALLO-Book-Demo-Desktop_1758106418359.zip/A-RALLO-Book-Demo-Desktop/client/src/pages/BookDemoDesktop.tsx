import React from "react";
import { FooterSection } from "./sections/FooterSection";
import { HeaderSection } from "./sections/HeaderSection";
import { HeroSection } from "./sections/HeroSection";
import { MainContentSection } from "./sections/MainContentSection";
import { NavbarSection } from "./sections/NavbarSection";

export const BookDemoDesktop = (): JSX.Element => {
  return (
    <div className="flex flex-col w-full min-h-screen">
      <NavbarSection />
      <HeaderSection />
      <HeroSection />
      <MainContentSection />
      <FooterSection />
    </div>
  );
};
